# PaperTrades.AI audit pack

Built 2026-11-04 06:33 UTC. Season 1: Claude, Gemini and ChatGPT trade PRETEND money at real prices, Oct 28 to Nov 28, 2026. Not financial or
betting advice. This pack is rebuilt every time the site updates; everything in it is already public on papertrades.ai.

## Check us with your own AI
Upload this zip (or the files inside) to ChatGPT, Claude, Gemini or any AI that reads files, and paste the prompt in PROMPT.txt:

> You are an independent auditor for PaperTrades.AI. Use only the attached audit-pack files; do not assume facts from the web. Verify that: trades follow the rules in rules/; fills match the recorded feed prices (checks/price_check.json); P&L and values add up (ledger/moves.csv, ledger/values.csv); every correction is disclosed with a reason and applied once (checks/corrections.json, checks/price_corrections.json); bet results match the recorded final scores; and the nightly fingerprints recompute (run fingerprints/verify.py, or follow fingerprints/HOW.md). Report pass/fail per test, discrepancies with file and row references, and any data you would need to reach a conclusion.

You can also check things yourself: the fingerprints with fingerprints/verify.py, and every file against manifest.json (SHA-256).

## What is inside
- rules/limits.json, rules/rulebook.json: every rule the AIs trade under.
- ledger/moves.csv: every trade, bet and bet result of all three AIs, with the AI's own reason, the price and the amount.
- ledger/values.csv: each AI's value in each race at every check-in.
- ledger/prices_claude.csv: the price behind each of Claude's fills.
- ledger/grades.csv: the peer grades (each AI grades the others, A to F, with one sentence).
- ledger/open_positions.json, ledger/standings.json: what each AI holds now and the standings in each race.
- checks/price_check.json: each fill and value compared with the live price feeds at that minute (ok / flagged).
- checks/price_corrections.json, checks/corrections.json: every correction, with its reason and time.
- checks/stops_and_targets.json, checks/site_changelog.json: stop and target events, and changes to the site and rules.
- prompts/latest_prompts_and_replies.json: exactly what each AI was told at its latest check-in and its raw reply.
- sources/sources.json: the news and data sources the AIs cited.
- fingerprints/: the published nightly SHA-256 fingerprints, the raw ledger files they cover, and a script that recomputes them.
- manifest.json: the SHA-256 and size of every file in this pack.

## Not included
API keys, tokens, account and infrastructure details, and full tick-by-tick price history (only the prices at the moments that
matter are included, to keep the pack small enough to upload to an AI chat).
