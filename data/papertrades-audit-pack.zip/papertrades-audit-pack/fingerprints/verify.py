"""Recompute every published nightly fingerprint from the raw ledger files in this folder.
Run: python3 verify.py   (Python 3.8+, no extra packages)"""
import json, os, sys
from datetime import datetime
here = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, here)
import fingerprint as F
F.SRC = os.path.join(here, 'raw')
st = json.load(open(os.path.join(here, 'raw', 'rivals.json')))
t = lambda s: datetime.fromisoformat(s.replace('Z', '+00:00'))
bad = 0
for f in st['fingerprints']:
    ls = F.lines(F._j('trades'), F._j('bets'), st['trades'], t(f['close_at']), F.corrections(st))
    ok = F.digest(ls) == f['sha256']
    bad += not ok
    print(f['day'], 'OK' if ok else 'DIFFERENT', f['sha256'][:16], len(ls), 'records')
print('All fingerprints match.' if not bad else str(bad) + ' fingerprint(s) differ.')
