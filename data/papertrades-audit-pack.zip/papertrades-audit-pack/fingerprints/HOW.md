# How the nightly fingerprints work

Each night, about 2 hours after the daily close (00:00 UTC), the race runner takes every trade and bet of all three AIs placed
before that close, writes each as one line, sorts the lines, joins them with a newline and publishes the SHA-256 of the result
(fingerprints/published.json, also posted on the Telegram channel @PaperTradesAI at the time). If anyone later changed an earlier
record, that day's hash would no longer match.

The exact line formats are at the top of fingerprint.py (the same code the race runs). To check: run `python3 verify.py` in this
folder, or rebuild the lines by hand from raw/ and hash them with any SHA-256 tool.
